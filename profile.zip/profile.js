const profileLoading = document.getElementById("profileLoading");
const profileContent = document.getElementById("profileContent");
const profileDisplayName = document.getElementById("profileDisplayName");
const profileUsername = document.getElementById("profileUsername");
const profileJoined = document.getElementById("profileJoined");
const profileAvatar = document.getElementById("profileAvatar");
const profileTabContent = document.getElementById("profileTabContent");
const profileCreatePostButton = document.getElementById("profileCreatePostButton");
const profileBioSection = document.getElementById("profileBioSection");
const profileBioInline = document.getElementById("profileBioInline");

let currentProfileTab = "posts";
let viewedAccount = null;
let currentAccount = null;
let viewingOwnProfile = false;
let profilePosts = [];
let profileLikes = null;   // เพิ่ม — null = ยังไม่เคยโหลด
let profileSaved = null;   // เพิ่ม
let editingPostId = null;
let deletingPostId = null;
let selectedAvatarFile = null;

function formatJoinedDate(dateValue) {
    if (!dateValue) return "Joined date unavailable";

    const date = new Date(dateValue);
    return `Joined ${date.toLocaleDateString("th-TH", {
        year: "numeric",
        month: "long",
        day: "numeric"
    })}`;
}

function formatPostTime(dateValue) {
    const date = new Date(dateValue);
    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleString("th-TH", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
}

function displayAccount(account) {
    profileDisplayName.textContent = account.displayName || account.username || "Unknown";
    profileUsername.textContent = `@${account.username || "unknown"}`;
    profileJoined.textContent = formatJoinedDate(account.createdAt);
    setAvatar(profileAvatar, account);

    const hasBio = Boolean(account.bio && account.bio.trim());
    profileBioSection.hidden = !hasBio;
    profileBioInline.textContent = hasBio ? account.bio.trim() : "";
}

async function fetchProfileAccount(accountId) {
    const response = await fetch(`${ACKI_API_URL}/accounts/${accountId}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Cannot load profile");
    return data.account || data;
}

async function loadProfilePosts() {
    if (!viewedAccount?.id) return;

    const response = await fetch(`${ACKI_API_URL}/accounts/${viewedAccount.id}/posts`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Cannot load posts");

    profilePosts = Array.isArray(data) ? data : [];
    if (currentProfileTab === "posts") renderPostsTab();
}

async function loadProfile() {
    const params = new URLSearchParams(window.location.search);
    const requestedId = Number(params.get("id"));
    currentAccount = getStoredAccount();

    const hasRequestedId = Number.isInteger(requestedId) && requestedId > 0;

    try {
        if (!hasRequestedId) {
            if (!isLoggedIn()) {
                window.location.href = "./login.html";
                return;
            }
            viewedAccount = await fetchCurrentAccount();
        } else {
            viewedAccount = await fetchProfileAccount(requestedId);
        }

        currentAccount = getStoredAccount() || currentAccount;
        viewingOwnProfile = Boolean(
            currentAccount && String(currentAccount.id) === String(viewedAccount.id)
        );

        displayAccount(viewedAccount);
        profileCreatePostButton.hidden = !viewingOwnProfile;
        document.getElementById("profileMenuWrap").hidden = !viewingOwnProfile;
        document.querySelector('.profile-tab[data-tab="saved"]').hidden = !viewingOwnProfile;
        profileLoading.hidden = true;
        profileContent.hidden = false;

        await loadProfilePosts();
    } catch (error) {
        profileLoading.textContent = error.message;
    }
}

async function switchProfileTab(tab, button) {
    currentProfileTab = tab;
    document.querySelectorAll(".profile-tab").forEach((tabButton) => {
        tabButton.classList.remove("active");
    });
    button.classList.add("active");
    await renderProfileTab(tab);
}

function renderPostList(posts, emptyIcon, emptyText) {
    profileTabContent.innerHTML = "";

    if (!posts || posts.length === 0) {
        profileTabContent.innerHTML = `
            <div class="profile-empty-state">
                <i class="ti ${emptyIcon}"></i>
                <p>${emptyText}</p>
            </div>
        `;
        return;
    }

    const grid = document.createElement("div");
    grid.className = "profile-post-grid";
    posts.forEach((post) => grid.appendChild(createProfilePostCard(post)));
    profileTabContent.appendChild(grid);
}

function toggleProfileHeaderMenu(event) {
    event.stopPropagation();
    document.getElementById("profileHeaderMenu").classList.toggle("show");
}

function shareProfileLink() {
    document.getElementById("profileHeaderMenu")?.classList.remove("show");

    const link = `${window.location.origin}${window.location.pathname}?id=${viewedAccount.id}`;

    if (navigator.share) {
        navigator.share({ title: viewedAccount.displayName || viewedAccount.username, url: link }).catch(() => { });
        return;
    }

    navigator.clipboard.writeText(link)
        .then(() => alert("Profile link copied!"))
        .catch(() => prompt("Copy this link:", link));
}

function openEditProfileModal() {
    document.getElementById("profileHeaderMenu")?.classList.remove("show");
    if (!viewingOwnProfile) return;

    document.getElementById("editProfileDisplayName").value = viewedAccount.displayName || "";
    document.getElementById("editProfileUsername").value = viewedAccount.username || "";
    document.getElementById("editProfileBio").value = viewedAccount.bio || "";
    document.getElementById("editProfileError").hidden = true;

    const avatarPreview = document.getElementById("avatarPreview");
    let avatar =
        viewedAccount.avatarUrl;

    if (
        avatar &&
        avatar.startsWith("/")
    ) {
        avatar =
            ACKI_API_URL +
            avatar;
    }

    avatarPreview.src =
        avatar ||
        "../pic/startpfp.jpg";

    document.getElementById("profileEditOverlay").classList.add("show");
    document.getElementById("editProfileModal").classList.add("show");
}

function closeEditProfileModal() {
    document.getElementById("profileEditOverlay").classList.remove("show");
    document.getElementById("editProfileModal").classList.remove("show");
}

async function submitEditProfile() {
    const token = getToken();
    if (!token) return;

    const displayName = document.getElementById("editProfileDisplayName").value.trim();
    const username = document.getElementById("editProfileUsername").value.trim();
    const bio = document.getElementById("editProfileBio").value.trim();
    const errorBox = document.getElementById("editProfileError");
    const submitButton = document.getElementById("editProfileSubmit");

    errorBox.hidden = true;
    submitButton.disabled = true;

    try {
        const response = await fetch(`${ACKI_API_URL}/me`, {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({
                displayName,
                bio
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Cannot update profile");

        let updatedAccount = data.account;

        if (username && username !== viewedAccount.username) {
            const accountResponse = await fetch(`${ACKI_API_URL}/me/account`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ username })
            });

            const accountData = await accountResponse.json();
            if (!accountResponse.ok) throw new Error(accountData.message || "Cannot update username");

            updatedAccount = accountData.account;
        }

        viewedAccount = updatedAccount;
        currentAccount = updatedAccount;
        if (selectedAvatarFile) {

            const formData =
                new FormData();

            formData.append(

                "avatar",

                selectedAvatarFile

            );

            const uploadResponse =
                await fetch(

                    `${ACKI_API_URL}/me/avatar`,

                    {

                        method: "POST",

                        headers: {

                            Authorization:

                                `Bearer ${token}`

                        },

                        body: formData

                    }

                );

            const uploadData =
                await uploadResponse.json();

            if (!uploadResponse.ok) {

                throw new Error(

                    uploadData.message

                );

            }

            updatedAccount =
                uploadData.account;

        }

        viewedAccount = updatedAccount;
        currentAccount = updatedAccount;
        localStorage.setItem(ACKI_ACCOUNT_KEY, JSON.stringify(updatedAccount));

        displayAccount(viewedAccount);
        selectedAvatarFile = null;
        document.getElementById("avatarInput").value = "";

        closeEditProfileModal();

        const avatarInput =
            document.getElementById("avatarInput");

        if (avatarInput) {
            avatarInput.value = "";
        }
    } catch (error) {
        errorBox.textContent = error.message;
        errorBox.hidden = false;
    } finally {
        submitButton.disabled = false;
    }
}

async function renderProfileTab(tab) {
    if (tab === "posts") {
        renderPostsTab();
        return;
    }

    profileTabContent.innerHTML = `<p class="profile-loading">Loading...</p>`;

    try {
        if (tab === "likes") {
            if (profileLikes === null) {
                const response = await fetch(`${ACKI_API_URL}/accounts/${viewedAccount.id}/likes`, {
                    headers: getToken() ? { Authorization: `Bearer ${getToken()}` } : {}
                });
                const data = await response.json();
                if (!response.ok) throw new Error(data.message || "Cannot load liked posts");
                profileLikes = Array.isArray(data) ? data : [];
            }
            renderPostList(profileLikes, "ti-heart", "Liked posts will appear here.");
        } else if (tab === "saved") {
            if (profileSaved === null) {
                const response = await fetch(`${ACKI_API_URL}/accounts/${viewedAccount.id}/saved`, {
                    headers: { Authorization: `Bearer ${getToken()}` }
                });
                const data = await response.json();
                if (!response.ok) throw new Error(data.message || "Cannot load saved posts");
                profileSaved = Array.isArray(data) ? data : [];
            }
            renderPostList(profileSaved, "ti-bookmark", "Saved posts will appear here.");
        }
    } catch (error) {
        profileTabContent.innerHTML = `
            <div class="profile-empty-state">
                <i class="ti ti-alert-circle"></i>
                <p>${error.message}</p>
            </div>
        `;
    }
}

function createOwnerButton(post) {
    const owner = document.createElement("button");
    owner.type = "button";
    owner.className = "profile-card-owner";
    owner.addEventListener("click", (event) => {
        event.stopPropagation();
        window.location.href = `./profile.html?id=${post.account.id}`;
    });

    const avatar = document.createElement("span");
    avatar.className = "profile-card-avatar";
    setAvatar(avatar, post.account);

    const identity = document.createElement("span");
    identity.className = "profile-card-identity";

    const name = document.createElement("strong");
    name.textContent = post.account.displayName || post.account.username || "Unknown";

    const username = document.createElement("small");
    username.textContent = `@${post.account.username || "unknown"}`;

    identity.append(name, username);
    owner.append(avatar, identity);
    return owner;
}

function createProfilePostCard(post) {
    const card = document.createElement("article");
    card.className = "profile-post-card";
    card.tabIndex = 0;
    card.addEventListener("click", () => openPostFromProfile(post.id));
    card.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            openPostFromProfile(post.id);
        }
    });

    const header = document.createElement("header");
    header.className = "profile-card-header";
    header.appendChild(createOwnerButton(post));

    if (viewingOwnProfile) {
        const menuWrap = document.createElement("div");
        menuWrap.className = "profile-card-menu-wrap";

        const menuButton = document.createElement("button");
        menuButton.type = "button";
        menuButton.className = "profile-card-menu-button";
        menuButton.innerHTML = '<i class="ti ti-dots"></i>';
        menuButton.addEventListener("click", (event) => {
            event.stopPropagation();
            document.querySelectorAll(".profile-card-menu.show").forEach((menu) => {
                if (menu !== menuButton.nextElementSibling) menu.classList.remove("show");
            });
            menuButton.nextElementSibling.classList.toggle("show");
        });

        const menu = document.createElement("div");
        menu.className = "profile-card-menu";
        menu.innerHTML = `
            <button type="button" data-action="edit"><i class="ti ti-pencil"></i> Edit</button>
            <button type="button" data-action="delete" class="danger"><i class="ti ti-trash"></i> Delete</button>
        `;
        menu.addEventListener("click", (event) => event.stopPropagation());
        menu.querySelector('[data-action="edit"]').addEventListener("click", () => openProfileComposer(post));
        menu.querySelector('[data-action="delete"]').addEventListener("click", () => openProfileDeleteModal(post.id));

        menuWrap.append(menuButton, menu);
        header.appendChild(menuWrap);
    }

    const text = document.createElement("p");
    text.className = "profile-card-text";
    text.textContent = post.content;

    const footer = document.createElement("footer");
    footer.className = "profile-card-footer";
    footer.innerHTML = `
        <span><i class="ti ti-heart"></i>${post.likeCount ?? 0}</span>
        <span><i class="ti ti-message-circle"></i>${post.commentCount ?? 0}</span>
        <time>${formatPostTime(post.createdAt)}</time>
    `;

    card.append(header, text, footer);
    return card;
}

function renderPostsTab() {
    profileTabContent.innerHTML = "";

    if (profilePosts.length === 0) {
        profileTabContent.innerHTML = `
            <div class="profile-empty-state">
                <i class="ti ti-notes"></i>
                <p>No posts yet.</p>
            </div>
        `;
        return;
    }

    const grid = document.createElement("div");
    grid.className = "profile-post-grid";
    profilePosts.forEach((post) => grid.appendChild(createProfilePostCard(post)));
    profileTabContent.appendChild(grid);
}

function openPostFromProfile(postId) {
    window.location.href = `./community.html?post=${postId}`;
}

function openProfileComposer(post = null) {
    if (!viewingOwnProfile) return;

    editingPostId = post?.id || null;
    document.getElementById("profileComposerTitle").textContent = editingPostId ? "Edit Post" : "Create Post";
    document.getElementById("profileComposerSubmit").textContent = editingPostId ? "Save" : "Post";
    document.getElementById("profileComposerText").value = post?.content || "";

    const composer = document.getElementById("profileComposer");
    composer.classList.add("show");
    composer.setAttribute("aria-hidden", "false");
    setTimeout(() => document.getElementById("profileComposerText").focus(), 250);
}

function closeProfileComposer() {
    const composer = document.getElementById("profileComposer");
    composer.classList.remove("show");
    composer.setAttribute("aria-hidden", "true");
    editingPostId = null;
    document.getElementById("profileComposerText").value = "";
}

async function submitProfilePost() {
    const token = getToken();
    const textarea = document.getElementById("profileComposerText");
    const submitButton = document.getElementById("profileComposerSubmit");
    const content = textarea.value.trim();

    if (!token || !content) return;

    submitButton.disabled = true;

    try {
        const url = editingPostId
            ? `${ACKI_API_URL}/posts/${editingPostId}`
            : `${ACKI_API_URL}/posts`;

        const response = await fetch(url, {
            method: editingPostId ? "PATCH" : "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({ content })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Cannot save post");

        closeProfileComposer();
        await loadProfilePosts();
    } catch (error) {
        alert(error.message);
    } finally {
        submitButton.disabled = false;
    }
}

function openProfileDeleteModal(postId) {
    deletingPostId = postId;
    document.getElementById("profileDeleteOverlay").classList.add("show");
    document.getElementById("profileDeleteModal").classList.add("show");
}

function closeProfileDeleteModal() {
    deletingPostId = null;
    document.getElementById("profileDeleteOverlay").classList.remove("show");
    document.getElementById("profileDeleteModal").classList.remove("show");
}

async function confirmProfileDelete() {
    const token = getToken();
    if (!token || !deletingPostId) return;

    try {
        const response = await fetch(`${ACKI_API_URL}/posts/${deletingPostId}`, {
            method: "DELETE",
            headers: { Authorization: `Bearer ${token}` }
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Cannot delete post");

        closeProfileDeleteModal();
        await loadProfilePosts();
    } catch (error) {
        alert(error.message);
    }
}

document.addEventListener("DOMContentLoaded", async () => {

    loadProfile();

    const avatarInput = document.getElementById("avatarInput");
    const avatarPreview = document.getElementById("avatarPreview");

    console.log(avatarInput);
    console.log(avatarPreview);

    avatarInput?.addEventListener("change", (event) => {
        const file = event.target.files[0];

        if (!file) return;

        selectedAvatarFile = file;

        avatarPreview.src = URL.createObjectURL(file);
    });

});